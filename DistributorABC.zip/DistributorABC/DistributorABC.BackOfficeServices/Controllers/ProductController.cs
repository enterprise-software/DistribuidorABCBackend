﻿using DistributorABC.BackOfficeServices.Models;
using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using DistributorABC.Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DistributorABC.BackOfficeServices.Controllers
{
    [Route("api/[controller]")]
	[ApiController]
	public class ProductController : ControllerBase
	{
		private readonly IProductService productService;
        public ProductController(IProductService productService)
        {
			this.productService = productService;
        }
        // GET: api/<ProductController>
        [HttpGet]
		[AllowAnonymous]
		public async Task<List<Product>> Get()
		{
			return await productService.GetListAsync();
		}

		// GET api/<ProductController>/5
		[HttpGet("{id}")]
		[AllowAnonymous]
		public async Task<Product> Get(int id)
		{
			return await productService.GetByIdAsync(id);
		}

		// POST api/<ProductController>
		[HttpPost]
		[Authorize(Policy = Policies.Admin)]
		public async Task<Product> Post([FromBody] Product product)
		{
			return await productService.AddAsync(product);
		}

		// PUT api/<ProductController>/5
		[HttpPut("{id}")]
		[Authorize(Policy = Policies.Admin)]
		public void Put(int id, [FromBody] Product product)
		{
			Console.WriteLine(id);
			this.productService.UpdateAsync(product);
		}

		// DELETE api/<ProductController>/5
		[HttpDelete("{id}")]
		[Authorize(Policy = Policies.Admin)]
		public void Delete(int id)
		{
			productService.DeleteAsync(id);
		}
	}
}
