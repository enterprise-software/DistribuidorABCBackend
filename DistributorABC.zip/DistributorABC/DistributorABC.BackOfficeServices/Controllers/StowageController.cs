﻿using DistributorABC.BackOfficeServices.Models;
using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using DistributorABC.Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DistributorABC.BackOfficeServices.Controllers
{
    [Route("api/[controller]")]
	[ApiController]
	public class StowageController : ControllerBase
	{
		private readonly IStowageService stowageService;
        public StowageController(IStowageService stowageService)
        {
            this.stowageService = stowageService;
        }
        // GET: api/<StowageController>
        [HttpGet]
		[AllowAnonymous]
		public async Task<List<Stowage>> Get()
		{
			return await stowageService.GetListAsync();
		}

		// GET api/<StowageController>/5
		[HttpGet("{id}")]
		[AllowAnonymous]
		public async Task<Stowage> Get(int id)
		{
			return await stowageService.GetByIdAsync(id);
		}

		// POST api/<StowageController>
		[HttpPost]
		[Authorize(Policy = Policies.Admin)]
		public async Task<Stowage> Post([FromBody] Stowage stowage)
		{
			return await stowageService.AddAsync(stowage);
		}

		// PUT api/<StowageController>/5
		[HttpPut("{id}")]
		[Authorize(Policy = Policies.Admin)]
		public void Put(int id, [FromBody] string value)
		{
		}

		// DELETE api/<StowageController>/5
		[HttpDelete("{id}")]
		[Authorize(Policy = Policies.Admin)]
		public void Delete(int id)
		{
		}
	}
}
