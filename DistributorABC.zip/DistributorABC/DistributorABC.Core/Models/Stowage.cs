﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Core.Models
{
    public class Stowage
    {
        public int StowageId { get; set; }
        public string? Description { get; set; }
        public int Capacity { get; set; }
        public ICollection<StowageNumber> StowageNumbers { get; set; } = new List<StowageNumber>();
	}
}
