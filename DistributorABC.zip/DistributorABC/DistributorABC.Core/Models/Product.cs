﻿namespace DistributorABC.Core.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public decimal RetailPrice { get; set; }
        public decimal WholeSalePrice { get; set; }
		public ICollection<StowageNumber> StowageNumbers { get; set; } = new List<StowageNumber>();
	}
}