﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DistributorABC.Core.Models;

namespace DistributorABC.Core.IRepositories
{
    public interface IStowageRepository
	{
		public Task<List<Stowage>> GetListAsync();
		public Task<Stowage> GetByIdAsync(int Id);
		public Task<Stowage> AddAsync(Stowage stowage);
		public Task<int> UpdateAsync(Stowage stowage);
		public Task<int> DeleteAsync(int Id);
	}
}
