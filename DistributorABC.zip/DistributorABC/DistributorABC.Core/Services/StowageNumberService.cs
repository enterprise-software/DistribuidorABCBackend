﻿using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Core.Services
{
    public class StowageNumberService : IStowageNumberService
	{
		private readonly IStowageNumberRepository stowageNumberRepository;
		public StowageNumberService(IStowageNumberRepository stowageNumberRepository)
		{
			this.stowageNumberRepository = stowageNumberRepository;
		}
		public async Task<StowageNumber> AddAsync(StowageNumber stowageNumber)
		{
			return await stowageNumberRepository.AddAsync(stowageNumber);
		}

		public async Task<int> DeleteAsync(int Id)
		{
			return await stowageNumberRepository.DeleteAsync(Id);
		}

		public async Task<StowageNumber> GetByIdAsync(int Id)
		{
			return await stowageNumberRepository.GetByIdAsync(Id);
		}

		public async Task<List<StowageNumber>> GetListAsync()
		{
			return await stowageNumberRepository.GetListAsync();
		}

		public Task<int> UpdateAsync(StowageNumber stowageNumber)
		{
			throw new NotImplementedException();
		}
	}
}
