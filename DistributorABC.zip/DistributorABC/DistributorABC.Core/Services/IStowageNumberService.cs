﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DistributorABC.Core.Models;

namespace DistributorABC.Core.Services
{
    public interface IStowageNumberService
	{
		public Task<List<StowageNumber>> GetListAsync();
		public Task<StowageNumber> GetByIdAsync(int Id);
		public Task<StowageNumber> AddAsync(StowageNumber stowageNumber);
		public Task<int> UpdateAsync(StowageNumber stowageNumber);
		public Task<int> DeleteAsync(int Id);
	}
}
