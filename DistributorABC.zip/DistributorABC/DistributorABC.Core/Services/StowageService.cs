﻿using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Core.Services
{
    public class StowageService: IStowageService
	{
		private readonly IStowageRepository stowageRepository;
		public StowageService(IStowageRepository stowageRepository)
		{
			this.stowageRepository = stowageRepository;
		}

		public async Task<Stowage> AddAsync(Stowage stowage)
		{
			return await stowageRepository.AddAsync(stowage);
		}

		public async Task<int> DeleteAsync(int Id)
		{
			return await stowageRepository.DeleteAsync(Id);
		}

		public async Task<Stowage> GetByIdAsync(int Id)
		{
			return await stowageRepository.GetByIdAsync(Id);
		}

		public async Task<List<Stowage>> GetListAsync()
		{
			return await stowageRepository.GetListAsync();
		}

		public Task<int> UpdateAsync(Stowage stowage)
		{
			throw new NotImplementedException();
		}
	}
}
