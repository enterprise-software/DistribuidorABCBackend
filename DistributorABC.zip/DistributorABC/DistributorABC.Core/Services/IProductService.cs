﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DistributorABC.Core.Models;

namespace DistributorABC.Core.Services
{
    public interface IProductService
	{
		public Task<List<Product>> GetListAsync();
		public Task<Product> GetByIdAsync(int Id);
		public Task<Product> AddAsync(Product product);
		public Task<int> UpdateAsync(Product product);
		public void DeleteAsync(int Id);
	}
}
