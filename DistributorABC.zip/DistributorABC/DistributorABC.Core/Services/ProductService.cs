﻿using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Core.Services
{
    public class ProductService : IProductService
	{
		private readonly IProductRepository productRepository;
        public ProductService(IProductRepository productRepository)
        {
			this.productRepository = productRepository;
        }
        public async Task<Product> AddAsync(Product product)
		{

			return await productRepository.AddAsync(product);
		}

		public void DeleteAsync(int Id)
		{
			productRepository.DeleteAsync(Id);
		}

		public async Task<Product> GetByIdAsync(int Id)
		{
			return await productRepository.GetByIdAsync(Id);
		}

		public async Task<List<Product>> GetListAsync()
		{
			return await productRepository.GetListAsync();
		}

		public async Task<int> UpdateAsync(Product product)
		{
			return await productRepository.UpdateAsync(product);
		}
	}
}
