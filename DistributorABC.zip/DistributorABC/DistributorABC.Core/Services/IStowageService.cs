﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DistributorABC.Core.Models;

namespace DistributorABC.Core.Services
{
    public interface IStowageService
	{
		public Task<List<Stowage>> GetListAsync();
		public Task<Stowage> GetByIdAsync(int Id);
		public Task<Stowage> AddAsync(Stowage product);
		public Task<int> UpdateAsync(Stowage product);
		public Task<int> DeleteAsync(int Id);
	}
}
