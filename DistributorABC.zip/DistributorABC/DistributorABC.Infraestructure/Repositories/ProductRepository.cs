﻿using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Infraestructure.Repositories
{
    public class ProductRepository : IProductRepository
	{
		private readonly DistributorABCDbContext distributorABCDbContext;
		public ProductRepository(DistributorABCDbContext distributorABCDbContext)
		{
			this.distributorABCDbContext = distributorABCDbContext ?? throw new ArgumentNullException(nameof(distributorABCDbContext));
		}
		public async Task<Product> AddAsync(Product product)
		{
			var result = distributorABCDbContext.Products.Add(product);
			await distributorABCDbContext.SaveChangesAsync();
			return result.Entity;
		}

		public void DeleteAsync(int Id)
		{
			var filtered = distributorABCDbContext.Products.Find(Id);
			if (filtered != null)
			{
				distributorABCDbContext.Products.Remove(filtered);
				distributorABCDbContext.SaveChanges();
			}
		}

		public async Task<Product> GetByIdAsync(int Id)
		{
			var result = await distributorABCDbContext.Products.Where(p => p.ProductId == Id).Include(x=>x.StowageNumbers).FirstOrDefaultAsync();
			return result ?? new Product();
		}

		public async Task<List<Product>> GetListAsync()
		{
			return await distributorABCDbContext.Products
				.Include(s=>s.StowageNumbers)
				.ToListAsync();
		}

		public async Task<int> UpdateAsync(Product product)
		{
			distributorABCDbContext.Products.Update(product);
			return await distributorABCDbContext.SaveChangesAsync();
		}
	}
}
