﻿using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using DistributorABC.Core.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Infraestructure.Repositories
{
    public class StowageRepository : IStowageRepository
	{
		private readonly DistributorABCDbContext distributorABCDbContext;
		public StowageRepository(DistributorABCDbContext distributorABCDbContext)
		{
			this.distributorABCDbContext = distributorABCDbContext ?? throw new ArgumentNullException(nameof(distributorABCDbContext));
		}
		public async Task<Stowage> AddAsync(Stowage stowage)
		{
			var result = distributorABCDbContext.Stowages.Add(stowage);
			await distributorABCDbContext.SaveChangesAsync();
			return result.Entity;
		}

		public async Task<int> DeleteAsync(int Id)
		{
			var filtered = distributorABCDbContext.Stowages.Where(p => p.StowageId == Id);
			distributorABCDbContext.Remove(filtered);
			return await distributorABCDbContext.SaveChangesAsync();
		}

		public async Task<Stowage> GetByIdAsync(int Id)
		{
			var result = await distributorABCDbContext.Stowages
    			.Include(x => x.StowageNumbers)
				.Where(p => p.StowageId == Id).FirstOrDefaultAsync();
			return result ?? new Stowage();
		}

		public async Task<List<Stowage>> GetListAsync()
		{
			var resp = await distributorABCDbContext.Stowages
				.Include(x => x.StowageNumbers)
				.ToListAsync();
			return resp;
		}

		public async Task<int> UpdateAsync(Stowage stowage)
		{
			distributorABCDbContext.Stowages.Update(stowage);
			return await distributorABCDbContext.SaveChangesAsync();
		}
	}
}
