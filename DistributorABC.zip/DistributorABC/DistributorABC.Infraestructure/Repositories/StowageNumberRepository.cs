﻿using DistributorABC.Core.IRepositories;
using DistributorABC.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client.Extensions.Msal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Infraestructure.Repositories
{
    public class StowageNumberRepository : IStowageNumberRepository
	{
		private readonly DistributorABCDbContext distributorABCDbContext;
		public StowageNumberRepository(DistributorABCDbContext distributorABCDbContext)
		{
			this.distributorABCDbContext = distributorABCDbContext ?? throw new ArgumentNullException(nameof(distributorABCDbContext));
		}
		public async Task<StowageNumber> AddAsync(StowageNumber stowageNumber)
		{
			var result = distributorABCDbContext.StowageNumbers.Add(stowageNumber);
			await distributorABCDbContext.SaveChangesAsync();
			return result.Entity;
		}

		public async Task<int> DeleteAsync(int Id)
		{
			var filtered = distributorABCDbContext.StowageNumbers.Where(p => p.StowageNumberId == Id);
			distributorABCDbContext.Remove(filtered);
			return await distributorABCDbContext.SaveChangesAsync();
		}

		public async Task<StowageNumber> GetByIdAsync(int Id)
		{
			var result = await distributorABCDbContext.StowageNumbers
				.Where(p => p.StowageNumberId == Id).FirstOrDefaultAsync();
			return result ?? new StowageNumber();
		}

		public Task<List<StowageNumber>> GetListAsync()
		{
			throw new NotImplementedException();
		}

		public Task<int> UpdateAsync(StowageNumber stowageNumber)
		{
			throw new NotImplementedException();
		}
	}
}
