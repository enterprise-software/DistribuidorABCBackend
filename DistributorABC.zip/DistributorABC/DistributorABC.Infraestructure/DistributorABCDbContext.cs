﻿using DistributorABC.Core.Models;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Metadata;

namespace DistributorABC.Infraestructure
{
    public class DistributorABCDbContext : DbContext
	{
		public DistributorABCDbContext(DbContextOptions<DistributorABCDbContext> options) : base(options)
		{
		}
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Product>()
				.Property(p => p.RetailPrice)
				.HasColumnType("decimal(18, 2)");

			modelBuilder.Entity<Product>()
				.Property(p => p.WholeSalePrice)
				.HasColumnType("decimal(18, 2)");

			modelBuilder.Entity<Stowage>()
				.HasMany(e => e.StowageNumbers)
				.WithOne()
				.HasForeignKey(e => e.StowageId)
				.IsRequired();

			modelBuilder.Entity<Product>()
				.HasMany(e => e.StowageNumbers)
				.WithOne()
				.HasForeignKey(e => e.ProductId)
				.IsRequired();
		}

		public DbSet<Product> Products { get; set; }
        public DbSet<Stowage> Stowages { get; set; }
        public DbSet<StowageNumber> StowageNumbers { get; set; }
	}
}