﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributorABC.Infraestructure
{
	public class DistributorABCDbContextFactory: IDesignTimeDbContextFactory<DistributorABCDbContext>
	{
		public DistributorABCDbContext CreateDbContext(string[] args)
		{
			var serviceProvider = new ServiceCollection()
				.AddDbContext<DistributorABCDbContext>(options =>
					options.UseSqlServer("Server=localhost;Database=DbDistributorABC;Trusted_Connection=True;TrustServerCertificate=True"))
				.BuildServiceProvider();

			return serviceProvider.GetRequiredService<DistributorABCDbContext>();
		}
	}
}
